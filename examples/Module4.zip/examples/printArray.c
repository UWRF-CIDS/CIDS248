#include <stdio.h>

int main()
{

    int array[5] = {2,5,3,6,4};
    for(int i = 0; i < 5000; i++)
    {
        printf("array[%d] = %d\n", i, array[i]);
    }

    return 0;

}