#include <stdio.h>  // imports printf
#include <stdlib.h> // imports rand
#include <time.h>   // imports time

int main()
{

    time_t seconds;
    seconds = time(NULL);
    srand(seconds);

    for (int i = 0; i < 10; i++)
    {

        int myRand = rand();
        printf("Random: %d\n", myRand);

    }

    return 0;
}